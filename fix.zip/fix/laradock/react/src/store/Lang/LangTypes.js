export const SET_LANG = 'SET_LANG';
export const GET_LANG = 'GET_LANG';