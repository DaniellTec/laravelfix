Formulario empleado

<h1>{{ $modo }} empleado</h1>

@if(count($errors)>0) <!-- Si hay errores los muestra -->

    <div clas="alert alert-danger" role="alert">
    <ul>
    @foreach($errors->all() as $error) <!-- Lista de errores -->
    <li> {{ $error }} </li>
     @endforeach
    </<ul>
    </div>

@endif

<div class="form-group">
<!-- Agrupa -->
<label for="Nombre"> Nombre </label>
<input type="text" class="form-control" name="Nombre" value="{{ isset($empleado->Nombre)?$empleado->Nombre:old('Nombre') }}" id="Nombre"> 
<!-- Si hay error conserva el campo anterior -->
 <br><br>
 </div>

 <div class="form-group">
 <label for="ApellidoPaterno"> ApellidoPaterno </label>
<input type="text" class="form-control" name="ApellidoPaterno" value="{{ isset($empleado->ApellidoPaterno)? $empleado->ApellidoPaterno:old('ApellidoPaterno') }}" id="ApellidoPaterno">
<br><br>
</div>

<div class="form-group">
<label for="ApellidoMaterno"> ApellidoMaterno </label>
<input type="text" class="form-control" name="ApellidoMaterno" value="{{ isset($empleado->ApellidoMaterno)? $empleado->ApellidoMaterno:old('ApellidoMaterno') }}" id="ApellidoMaterno">
<br><br>
</div>

<div class="form-group">
<label for="Email"> Email </label>
<input type="text" class="form-control" name="Email" value="{{ isset($empleado->Email)? $empleado->Email:old('Email') }}" id="Email">
<br><br>
</div>

<div class="form-group">
<label for="Foto"> Foto </label>

@if(isset($empleado->Foto))
<img class="img-thumbnail img-fluid" src="{{ asset('storage').'/'.$empleado->Foto }}" width="100" alt="">
@endif
<input class="btn btn-success" type="file" class="form-control" name="Foto" value="" id="Foto">
<br><br>
</div>

<input type="submit" value="{{ $modo }} datos"> 


<a class="btn btn-primary" href="{{ url('empleado/') }}">Regresar</a> <!-- Redirecciona al inicio -->

<br>


