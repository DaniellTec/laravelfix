Formulario empleado

<h1><?php echo e($modo); ?> empleado</h1>

<?php if(count($errors)>0): ?> <!-- Si hay errores los muestra -->

    <div clas="alert alert-danger" role="alert">
    <ul>
    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- Lista de errores -->
    <li> <?php echo e($error); ?> </li>
     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </<ul>
    </div>

<?php endif; ?>

<div class="form-group">
<!-- Agrupa -->
<label for="Nombre"> Nombre </label>
<input type="text" class="form-control" name="Nombre" value="<?php echo e(isset($empleado->Nombre)?$empleado->Nombre:old('Nombre')); ?>" id="Nombre"> 
<!-- Si hay error conserva el campo anterior -->
 <br><br>
 </div>

 <div class="form-group">
 <label for="ApellidoPaterno"> ApellidoPaterno </label>
<input type="text" class="form-control" name="ApellidoPaterno" value="<?php echo e(isset($empleado->ApellidoPaterno)? $empleado->ApellidoPaterno:old('ApellidoPaterno')); ?>" id="ApellidoPaterno">
<br><br>
</div>

<div class="form-group">
<label for="ApellidoMaterno"> ApellidoMaterno </label>
<input type="text" class="form-control" name="ApellidoMaterno" value="<?php echo e(isset($empleado->ApellidoMaterno)? $empleado->ApellidoMaterno:old('ApellidoMaterno')); ?>" id="ApellidoMaterno">
<br><br>
</div>

<div class="form-group">
<label for="Email"> Email </label>
<input type="text" class="form-control" name="Email" value="<?php echo e(isset($empleado->Email)? $empleado->Email:old('Email')); ?>" id="Email">
<br><br>
</div>

<div class="form-group">
<label for="Foto"> Foto </label>

<?php if(isset($empleado->Foto)): ?>
<img class="img-thumbnail img-fluid" src="<?php echo e(asset('storage').'/'.$empleado->Foto); ?>" width="100" alt="">
<?php endif; ?>
<input class="btn btn-success" type="file" class="form-control" name="Foto" value="" id="Foto">
<br><br>
</div>

<input type="submit" value="<?php echo e($modo); ?> datos"> 


<a class="btn btn-primary" href="<?php echo e(url('empleado/')); ?>">Regresar</a> <!-- Redirecciona al inicio -->

<br>


<?php /**PATH /var/www/resources/views/empleado/form.blade.php ENDPATH**/ ?>