Formulario de creación de empleado, crea información para que se muestre en la base de datos



<?php $__env->startSection('content'); ?>
<div class="container">  <!-- Muestra login & register -->

<form action="<?php echo e(url('/empleado')); ?>" method="post" enctype="multipart/form-data"> 
<!-- Se envía la información a esta ruta -> empleado.store -->
<?php echo csrf_field(); ?>
<?php echo $__env->make('empleado.form', ['modo' =>'Crear'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!--Da el mensaje al crear los datos --> 
<!-- Hace referencia al form -->

</form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/empleado/create.blade.php ENDPATH**/ ?>