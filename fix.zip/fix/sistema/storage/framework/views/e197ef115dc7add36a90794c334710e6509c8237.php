Formulario de edición de empleado



<?php $__env->startSection('content'); ?>
<div class="container"> <!-- Muestra login & register -->

<form action="<?php echo e(url('/empleado/'.$empleado->id)); ?>" method="post" enctype="multipart/form-data"> <!--  -->

<?php echo csrf_field(); ?> <!-- Cifra --> 
<?php echo e(method_field('PATCH')); ?> <!-- Actualiza los datos -->  
<?php echo $__env->make('empleado.form', ['modo' =>'Editar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> <!--Da el mensaje al editar los datos --> 

</form>

</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /var/www/resources/views/empleado/edit.blade.php ENDPATH**/ ?>